# Homework-4
HW4-winter20/21-MLH

Details for SSH connection (MobaXTerm):

ssh stuX@132.68.176.114  for triton01

OR 

ssh stuX@132.68.176.115  for triton02

Password - ML2021_X

Where X is your designated number.

Beatzlacha!
